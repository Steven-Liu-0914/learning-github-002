﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseEclSimulationResultData
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "apl_response_ecl_indicateur_data")]
        public AplResponseEclIndicateurData? AplResponseEclIndicateurData { get; set; }
    }
}
