﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseProfitabilityIndicatorSimulationResultData
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "apl_response_profitability_indicator_result_item")]
        public AplResponseProfitabilityIndicatorResultItem? AplResponseProfitabilityIndicatorResultItem { get; set; }

        [DataMember(Name = "apl_response_revenue_indicator_result_item")]
        public AplResponseRevenueIndicatorResultItem? AplResponseRevenueIndicatorResultItem { get; set; }

        [DataMember(Name = "apl_response_liquidity_cost_indicator_result_item")]
        public AplResponseLiquidityCostIndicatorResultItem? AplResponseLiquidityCostIndicatorResultItem { get; set; }

        [DataMember(Name = "apl_response_operational_risk_indicator_result_item")]
        public AplResponseOperationalRiskIndicatorResultItem? AplResponseOperationalRiskIndicatorResultItem { get; set; }

        [DataMember(Name = "apl_response_regulatory_indicateur_result_item")]
        public AplResponseRegulatoryIndicateurResultItem? AplResponseRegulatoryIndicateurResultItem { get; set; }
    }
}
