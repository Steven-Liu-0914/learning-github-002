﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseMapRwairbaPortion
    {
        [DataMember(Name = "rwairba_portion")]
        public AplResponseRwairbaPortion? RWAIRBAPortion { get; set; }
    }
}
