﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseProfitabilityIndicatorResultItem
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "ccy_result")]
        public string? CcyResult { get; set; }

        [DataMember(Name = "liquidity_cost")]
        public double? LiquidityCost { get; set; }

        [DataMember(Name = "expected_loss")]
        public double? ExpectedLoss { get; set; }

        [DataMember(Name = "total_cost")]
        public double? TotalCost { get; set; }

        [DataMember(Name = "rwa_credit_risk")]
        public double? RwaCreditRisk { get; set; }

        [DataMember(Name = "rwa_operational_risk")]
        public double? RwaOperationalRisk { get; set; }

        [DataMember(Name = "total_rwa")]
        public double? TotalRwa { get; set; }

        [DataMember(Name = "profitability_indicateur")]
        public double? ProfitabilityIndicateur { get; set; }

        [DataMember(Name = "monthly_profil")]
        public AplResponseMonthlyProfilData? MonthlyProfil { get; set; }
    }
}
