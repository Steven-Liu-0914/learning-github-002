﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseElementaryResult
    {
        [DataMember(Name = "ecl")]
        public AplResponseElementaryResultEcl? Ecl { get; set; }

        [DataMember(Name = "pi")]
        public AplResponseElementaryResultPi? Pi { get; set; }
    }
}
