﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseEclIndicateurData
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "is_with_portion")]
        public bool? IsWithPortion { get; set; }

        [DataMember(Name = "exposure")]
        public double? Exposure { get; set; }

        [DataMember(Name = "ead")]
        public double? Ead { get; set; }

        [DataMember(Name = "ecl")]
        public double? Ecl { get; set; }

        [DataMember(Name = "ecl_bucket_1")]
        public double? EclBucket1 { get; set; }

        [DataMember(Name = "ecl_bucket_2")]
        public double? EclBucket2 { get; set; }

        [DataMember(Name = "apl_response_map_ecl_portion_data")]
        public AplResponseMapEclPortionData? AplResponseMapEclPortionData { get; set; }
    }
}
