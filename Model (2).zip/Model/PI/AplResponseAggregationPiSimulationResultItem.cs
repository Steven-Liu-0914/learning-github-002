﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationPiSimulationResultItem
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "profitability_indicateur")]
        public AplResponseProfitabilityIndicatorResultItem? ProfitabilityIndicateur { get; set; }

        [DataMember(Name = "revenue_indicator")]
        public AplResponseRevenueIndicatorResultItem? RevenueIndicator { get; set; }

        [DataMember(Name = "liquidity_cost_indicator")]
        public AplResponseLiquidityCostIndicatorResultItem? LiquidityCostIndicator { get; set; }

        [DataMember(Name = "operational_risk_indicator")]
        public AplResponseOperationalRiskIndicatorResultItem? OperationalRiskIndicator { get; set; }

        [DataMember(Name = "eva_indicateur")]
        public AplResponseAggregationEvaIndicatorResultItem? EVAIndicateur { get; set; }

        [DataMember(Name = "regulatory_indicateur")]
        public AplResponseRegulatoryIndicateurResultItem? RegulatoryIndicateur { get; set; }
    }
}
