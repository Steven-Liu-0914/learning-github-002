﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationResult
    {
        [DataMember(Name = "ecl")]
        public AplResponseAggregationResultEcl? Ecl { get; set; }

        [DataMember(Name = "pi")]
        public AplResponseAggregationResultPI? PI { get; set; }
    }
}
