﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseRevenueIndicatorResultItem
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "technical_id")]
        public string? TechnicalId { get; set; }

        [DataMember(Name = "weighted_average_life")]
        public double? WeightedAverageLife { get; set; }

        [DataMember(Name = "ccy_result")]
        public string? CcyResult { get; set; }

        [DataMember(Name = "commitment")]
        public double? Commitment { get; set; }

        [DataMember(Name = "draw_amount")]
        public double? DrawAmount { get; set; }

        [DataMember(Name = "undrawn_amount")]
        public double? UndrawnAmount { get; set; }

        [DataMember(Name = "commitment_fee")]
        public double? CommitmentFee { get; set; }

        [DataMember(Name = "margin")]
        public double? Margin { get; set; }

        [DataMember(Name = "revenues")]
        public double? Revenues { get; set; }

        [DataMember(Name = "margin_and_commitment_fee_revenues")]
        public double? MarginAndCommitmentFeeRevenues { get; set; }

        [DataMember(Name = "facility_fee_revenues")]
        public double? FacilityFeeRevenues { get; set; }

        [DataMember(Name = "equivalent_facility_fee_in_basis_point")]
        public double? EquivalentFacilityFeeInBasisPoint { get; set; }

        [DataMember(Name = "equivalent_margin_and_commitment_fee_in_basis_point")]
        public double? EquivalentMarginAndCommitmentFeeInBasisPoint { get; set; }

        [DataMember(Name = "monthly_profil")]
        public AplResponseMonthlyProfilData? MonthlyProfil { get; set; }
    }
}
