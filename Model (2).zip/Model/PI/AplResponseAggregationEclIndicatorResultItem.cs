﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationEclIndicatorResultItem
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "ccy_result")]
        public string? CcyResult { get; set; }

        [DataMember(Name = "is_with_portion")]
        public bool? IsWithPortion { get; set; }

        [DataMember(Name = "exposure")]
        public double? Exposure { get; set; }

        [DataMember(Name = "ead")]
        public double? Ead { get; set; }

        [DataMember(Name = "ecl")]
        public double? Ecl { get; set; }
    }
}
