﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseRwairbaPortion
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "pd")]
        public double? PD { get; set; }

        [DataMember(Name = "lgd")]
        public double? LGD { get; set; }

        [DataMember(Name = "effective_maturity")]
        public double? EffectiveMaturity { get; set; }
    }
}
