﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseLiquidityCostIndicatorResultItem
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "ccy_result")]
        public string? CcyResult { get; set; }

        [DataMember(Name = "legal_entity_id")]
        public string? LegalEntityId { get; set; }

        [DataMember(Name = "category_id")]
        public string? CategoryId { get; set; }

        [DataMember(Name = "drawn_liquidity_cost_rate")]
        public double? DrawnLiquidityCostRate { get; set; }

        [DataMember(Name = "undrawn_liquidity_cost_rate")]
        public double? UndrawnLiquidityCostRate { get; set; }

        [DataMember(Name = "equivalent_liquidity_cost_in_basis_point")]
        public double? EquivalentLiquidityCostInBasisPoint { get; set; }

        [DataMember(Name = "monthly_profil")]
        public AplResponseMonthlyProfilData? MonthlyProfil { get; set; }
    }
}
