﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseMonthlyProfilData
    {
        [DataMember(Name = "date")]
        public List<DateTime?>? Date { get; set; }

        [DataMember(Name = "vect_revenue")]
        public List<double?>? VectRevenue { get; set; }

        [DataMember(Name = "vect_liquidity_cost")]
        public List<double?>? VectLiquidityCost { get; set; }

        [DataMember(Name = "vect_rwa_credit_risk")]
        public List<double?>? VectRWACreditRisk { get; set; }

        [DataMember(Name = "vect_rwa_operational_risk")]
        public List<double?>? VectRwaOperationlRisk { get; set; }

        [DataMember(Name = "vect_expected_loss")]
        public List<double?>? VectExpectedLoss { get; set; }

        [DataMember(Name = "vect_profitability_indicator")]
        public List<double?>? VectProfitabilityIndicator { get; set; }

        [DataMember(Name = "vect_eva")]
        public List<double?>? VectEVA { get; set; }

        [DataMember(Name = "vect_drawn")]
        public List<double?>? VectDrawn { get; set; }

        [DataMember(Name = "vect_undrawn")]
        public List<double?>? VectUndrawn { get; set; }

        [DataMember(Name = "vect_ratio")]
        public List<double?>? VectRatio { get; set; }

        [DataMember(Name = "vect_margin_revenue")]
        public List<double?>? VectMarginRevenue { get; set; }

        [DataMember(Name = "vect_utilization_fee_revenue")]
        public List<double?>? VectUtilizationFeeRevenue { get; set; }

        [DataMember(Name = "vect_commitment_revenue")]
        public List<double?>? VectCommitmentRevenue { get; set; }

        [DataMember(Name = "vect_facility_fee_revenue")]
        public List<double?>? VectFacilityFeeRevenue { get; set; }

        [DataMember(Name = "vect_floor_benefit_revenue")]
        public List<double?>? VectFloorBenefitRevenue { get; set; }

        [DataMember(Name = "vect_drawn_liquidity_cost")]
        public List<double?>? VectDrawnLiquidityCost { get; set; }

        [DataMember(Name = "vect_undrawn_liquidity_cost")]
        public List<double?>? VectUndrawnLiquidityCost { get; set; }

        [DataMember(Name = "vect_operational_risk_rwa")]
        public List<double?>? VectOperationalRiskRwa { get; set; }
    }
}
