﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseEclResultData
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "transaction_id")]
        public string? TransactionId { get; set; }

        [DataMember(Name = "tranch_id")]
        public string? TranchId { get; set; }

        [DataMember(Name = "is_in_ecl_perimeter")]
        public bool? IsInEclPerimeter { get; set; }

        [DataMember(Name = "is_in_ecl_perimeter_category")]
        public string? IsInEclPerimeterCategory { get; set; }

        [DataMember(Name = "is_in_ecl_perimeter_comment")]
        public string? IsInEclPerimeterComment { get; set; }

        [DataMember(Name = "calculation_type")]
        public string? CalculationType { get; set; }

        [DataMember(Name = "is_calculation_by_dll_mqp_succeeded")]
        public bool? IsCalculationByDllMqpSucceeded { get; set; }

        [DataMember(Name = "maturity")]
        public double? Maturity { get; set; }

        [DataMember(Name = "elapsed_time")]
        public double? ElapsedTime { get; set; }

        [DataMember(Name = "remaining_time")]
        public double? RemainingTime { get; set; }

        [DataMember(Name = "exposure")]
        public double? Exposure { get; set; }

        [DataMember(Name = "ccf")]
        public double? Ccf { get; set; }

        [DataMember(Name = "ead")]
        public double? Ead { get; set; }

        [DataMember(Name = "pd")]
        public double? Pd { get; set; }

        [DataMember(Name = "lgd")]
        public double? Lgd { get; set; }

        [DataMember(Name = "ecl")]
        public double? Ecl { get; set; }

        [DataMember(Name = "bucket")]
        public string? Bucket { get; set; }

        [DataMember(Name = "bucket_details")]
        public string? BucketDetails { get; set; }

        [DataMember(Name = "bucket_low_credit_risk")]
        public string? BucketLowCreditRisk { get; set; }

        [DataMember(Name = "bucket_sensitive_cpty")]
        public string? BucketSensitiveCpty { get; set; }

        [DataMember(Name = "bucket_downgrade_rating")]
        public string? BucketDowngradeRating { get; set; }

        [DataMember(Name = "bucket_sensitive_segment")]
        public string? BucketSensitiveSegment { get; set; }

        [DataMember(Name = "fll_segment_scenario")]
        public double? FLL_Segment_Scenario { get; set; }

        [DataMember(Name = "fll_region")]
        public string? FLL_Region { get; set; }

        [DataMember(Name = "fll_segment")]
        public string? FLL_Segment { get; set; }

        [DataMember(Name = "fll_scenario")]
        public double? FLL_Scenario { get; set; }

        [DataMember(Name = "fll_product_penalty")]
        public double? FLL_Product_Penalty { get; set; }

        [DataMember(Name = "fll_country_penalty")]
        public double? FLL_Country_Penalty { get; set; }

        [DataMember(Name = "ccf_curve")]
        public string? CCFCurve { get; set; }

        [DataMember(Name = "lgd_type")]
        public string? LGDType { get; set; }

        [DataMember(Name = "lgd_curve")]
        public string? LGDCurve { get; set; }

        [DataMember(Name = "pd_method")]
        public string? PDMethod { get; set; }

        [DataMember(Name = "pd_curve")]
        public string? PDCurve { get; set; }
    }
}
