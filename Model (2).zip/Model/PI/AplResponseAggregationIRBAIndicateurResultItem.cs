﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationIrbaIndicateurResultItem
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "is_with_portion")]
        public bool? IsWithPortion { get; set; }

        [DataMember(Name = "ccy_result")]
        public string? CcyResult { get; set; }

        [DataMember(Name = "counterparty_id")]
        public string? CounterpartyId { get; set; }

        [DataMember(Name = "ead_before_ccf_application")]
        public double? EadBeforeCCFApplication { get; set; }

        [DataMember(Name = "ead")]
        public double? EAD { get; set; }

        [DataMember(Name = "average_effective_maturity")]
        public double? AverageEffectiveMaturity { get; set; }

        [DataMember(Name = "rwa")]
        public double? RWA { get; set; }

        [DataMember(Name = "nb_rwa_irba_portion")]
        public int? NbRWAIRBAPortion { get; set; }

        [DataMember(Name = "map_rwa_irba_portion")]
        public AplResponseMapRwairbaPortion? MapRWAIRBAPortion { get; set; }
    }
}
