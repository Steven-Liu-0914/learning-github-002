﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationResultEcl
    {
        [DataMember(Name = "f1")]
        public List<AplResponseAggregationEclSimulationResultItem>? F1 { get; set; }

        [DataMember(Name = "f2")]
        public List<AplResponseAggregationEclSimulationResultItem>? F2 { get; set; }

        [DataMember(Name = "counterparty")]
        public List<AplResponseAggregationEclSimulationResultItem>? Counterparty { get; set; }

        [DataMember(Name = "portfolio")]
        public List<AplResponseAggregationEclSimulationResultItem>? Portfolio { get; set; }
    }
}
