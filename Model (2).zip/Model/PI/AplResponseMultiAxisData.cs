﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseMultiAxisData
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "vect_axis_id")]
        public List<string>? VectAxisId { get; set; }

        [DataMember(Name = "vect_axis_value")]
        public List<string>? VectAxisValue { get; set; }
    }
}
