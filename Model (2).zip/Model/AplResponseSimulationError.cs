﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseSimulationError
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "technical_id")]
        public string? TechnicalId { get; set; }

        [DataMember(Name = "level")]
        public string? Level { get; set; }

        [DataMember(Name = "level_id")]
        public string? LevelId { get; set; }

        [DataMember(Name = "error")]
        public string? Error { get; set; }
    }
}
