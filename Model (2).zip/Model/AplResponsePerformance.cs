﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponsePerformance
    {
        [DataMember(Name = "elapsed_time")]
        public double? ElapsedTime { get; set; }

        [DataMember(Name = "unit")]
        public string? Unit { get; set; }
    }
}
