﻿using System;
using System.Runtime.Serialization; // Add this reference to support [DataMember]

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseContainer
    {
        //Shared Response
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "client_id")]
        public string? ClientId { get; set; }

        [DataMember(Name = "context_id")]
        public string? ContextId { get; set; }

        [DataMember(Name = "cut_off_id")]
        public string? CutOffId { get; set; }

        [DataMember(Name = "client_simulation_id")]
        public string? ClientSimulationId { get; set; }

        //PI
        [DataMember(Name = "aggregation_result")]
        public AplResponseAggregationResult? AggregationResult { get; set; }

        [DataMember(Name = "elementary_result")]
        public AplResponseElementaryResult? ElementaryResult { get; set; }

        //LGD
        [DataMember(Name = "simulation_time")]
        public DateTime? SimulationTime { get; set; }

        [DataMember(Name = "user_ut")]
        public string? UserUT { get; set; }

        [DataMember(Name = "is_official_calculation_with_db_insertion")]
        public bool? IsOfficialCalculationWithDbInsertion { get; set; }

        [DataMember(Name = "simulation_requested_result")]
        public SimulationRequestedResult? SimulationRequestedResult { get; set; }

        [DataMember(Name = "specialized_lending_project")]
        public SpecializedLendingProject? SpecializedLendingProject { get; set; }

        [DataMember(Name = "legal_entity_data")]
        public LegalEntityData? LegalEntityData { get; set; }
    }
}
