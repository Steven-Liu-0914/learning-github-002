﻿using System;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class SpecializedLendingProject
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "project_id")]
        public string? ProjectId { get; set; }

        [DataMember(Name = "spv_id")]
        public string? SpvId { get; set; }

        [DataMember(Name = "spv_risk_country")]
        public string? SpvRiskCountry { get; set; }

        [DataMember(Name = "sector")]
        public string? Sector { get; set; }

        [DataMember(Name = "head_of_commercial_origin")]
        public string? HeadOfCommercialOrigin { get; set; }

        [DataMember(Name = "commercial_origination_entity")]
        public object? CommercialOriginationEntity { get; set; }

        [DataMember(Name = "is_acquisition")]
        public bool? IsAcquisition { get; set; }

        [DataMember(Name = "target_commercial_operation_date")]
        public DateTime? TargetCommercialOperationDate { get; set; }

        [DataMember(Name = "actual_commercial_operation_date")]
        public DateTime? ActualCommercialOperationDate { get; set; }

        [DataMember(Name = "is_project_in_exploitation_phase")]
        public bool? IsProjectInExploitationPhase { get; set; }

        [DataMember(Name = "is_brown_field_at_inception")]
        public bool? IsBrownFieldAtInception { get; set; }

        [DataMember(Name = "is_partial_off_take")]
        public bool? IsPartialOffTake { get; set; }

        [DataMember(Name = "maturity_off_take_to_debt_maturity_ratio")]
        public DateTime? MaturityOffTakeToDebtMaturityRatio { get; set; }

        [DataMember(Name = "is_accessible_cashflow")]
        public bool? IsAccessibleCashflow { get; set; }

        [DataMember(Name = "full_off_take_contract_maturity_date")]
        public DateTime? FullOffTakeContractMaturityDate { get; set; }

        [DataMember(Name = "is_liquid_asset")]
        public bool? IsLiquidAsset { get; set; }

        [DataMember(Name = "is_joint_contractor_in_case_epc_jv")]
        public bool? IsJointContractorInCaseEPCJV { get; set; }

        [DataMember(Name = "is_several_contractor_in_case_epc_jv")]
        public bool? IsSeveralContractorInCaseEPCJV { get; set; }

        [DataMember(Name = "force_belongs_to_supporting_group_in_case_of_default")]
        public bool? ForceBelongsToSupportingGroupInCaseOfDefault { get; set; }

        [DataMember(Name = "comment")]
        public string? Comment { get; set; }

        [DataMember(Name = "sponsor_specify_comment")]
        public string? SponsorSpecifyComment { get; set; }

        [DataMember(Name = "version")]
        public object? Version { get; set; }

        [DataMember(Name = "status")]
        public string? Status { get; set; }

        [DataMember(Name = "sti1_id")]
        public string? Sti1Id { get; set; }

        [DataMember(Name = "product_line")]
        public string? ProductLine { get; set; }

        [DataMember(Name = "credit_file_label")]
        public string? CreditFileLabel { get; set; }

        [DataMember(Name = "fo_analyst_code")]
        public string? FoAnalystCode { get; set; }

        [DataMember(Name = "project_contractor_data")]
        public ProjectContractorData? ProjectContractorData { get; set; }

        [DataMember(Name = "project_sponsor_data")]
        public ProjectSponsorData? ProjectSponsorData { get; set; }

        [DataMember(Name = "project_off_taker_data")]
        public ProjectOffTakerData? ProjectOffTakerData { get; set; }
    }
}
