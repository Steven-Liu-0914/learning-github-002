﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class ProjectContractorData
    {
        [DataMember(Name = "project_contractor")]
        public List<ProjectContractor>? ProjectContractor { get; set; }
    }
}
