﻿using System;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class ProjectOffTaker
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "with_ricos_id")]
        public bool? WithRicosId { get; set; }

        [DataMember(Name = "ricos_id")]
        public string? RicosId { get; set; }

        [DataMember(Name = "short_name")]
        public string? ShortName { get; set; }

        [DataMember(Name = "are_cashflows_contracted")]
        public bool? AreCashflowsContracted { get; set; }

        [DataMember(Name = "are_cashflows_over_loan_maturity")]
        public bool? AreCashflowsOverLoanMaturity { get; set; }

        [DataMember(Name = "contract_cashflow_to_debt_ratio")]
        public double? ContractCashflowToDebtRatio { get; set; }

        [DataMember(Name = "comment")]
        public string? Comment { get; set; }
    }
}
