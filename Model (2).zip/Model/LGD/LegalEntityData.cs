﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class LegalEntityData
    {
        [DataMember(Name = "legal_entity_data_list")]
        public List<LegalEntityDataList>? LegalEntityDataList { get; set; }
    }
}
