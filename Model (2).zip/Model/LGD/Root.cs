﻿using System;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class Root
    {
        [DataMember(Name = "container")]
        public Container? Container { get; set; }
    }
}
