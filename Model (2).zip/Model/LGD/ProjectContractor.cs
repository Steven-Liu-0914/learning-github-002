﻿using System;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class ProjectContractor
    {
        [DataMember(Name = "leaf_type")]
        public string? LeafType { get; set; }

        [DataMember(Name = "id")]
        public string? Id { get; set; }

        [DataMember(Name = "with_ricos_id")]
        public bool? WithRicosId { get; set; }

        [DataMember(Name = "ricos_id")]
        public string? RicosId { get; set; }

        [DataMember(Name = "short_name")]
        public string? ShortName { get; set; }

        [DataMember(Name = "repartition")]
        public double? Repartition { get; set; }

        [DataMember(Name = "comment")]
        public string? Comment { get; set; }
    }
}
