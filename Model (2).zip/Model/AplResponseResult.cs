﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseResult
    {
        [DataMember(Name = "container")]
        public AplResponseContainer? Container { get; set; }

        [DataMember(Name = "simulation_error")]
        public AplResponseSimulationError? SimulationError { get; set; }

        [DataMember(Name = "performance")]
        public AplResponsePerformance? Performance { get; set; }
    }
}
