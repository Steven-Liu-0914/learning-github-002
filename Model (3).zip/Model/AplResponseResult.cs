﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseResult
    {
        [JsonPropertyName( "container")]
        public AplResponseContainer? Container { get; set; }

        [JsonPropertyName( "simulation_error")]
        public AplResponseSimulationError? SimulationError { get; set; }

        [JsonPropertyName( "performance")]
        public AplResponsePerformance? Performance { get; set; }
    }
}
