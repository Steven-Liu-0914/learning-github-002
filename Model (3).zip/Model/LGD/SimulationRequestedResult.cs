﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class SimulationRequestedResult
    {
        [JsonPropertyName( "output_indicators")]
        public List<string>? OutputIndicators { get; set; }
    }
}
