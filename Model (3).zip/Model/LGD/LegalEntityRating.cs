﻿using System;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class LegalEntityRating
    {
        [JsonPropertyName( "rating_agency")]
        public string? RatingAgency { get; set; }

        [JsonPropertyName( "rating")]
        public string? Rating { get; set; }

        [JsonPropertyName( "rating_date")]
        public DateTime? RatingDate { get; set; }
    }
}
