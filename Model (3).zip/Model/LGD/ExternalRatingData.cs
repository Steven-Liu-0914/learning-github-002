﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class ExternalRatingData
    {
        [JsonPropertyName( "legal_entity_ratings")]
        public List<LegalEntityRating>? LegalEntityRatings { get; set; }
    }
}
