﻿using System;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class SpecializedLendingProject
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "project_id")]
        public string? ProjectId { get; set; }

        [JsonPropertyName( "spv_id")]
        public string? SpvId { get; set; }

        [JsonPropertyName( "spv_risk_country")]
        public string? SpvRiskCountry { get; set; }

        [JsonPropertyName( "sector")]
        public string? Sector { get; set; }

        [JsonPropertyName( "head_of_commercial_origin")]
        public string? HeadOfCommercialOrigin { get; set; }

        [JsonPropertyName( "commercial_origination_entity")]
        public object? CommercialOriginationEntity { get; set; }

        [JsonPropertyName( "is_acquisition")]
        public bool? IsAcquisition { get; set; }

        [JsonPropertyName( "target_commercial_operation_date")]
        public DateTime? TargetCommercialOperationDate { get; set; }

        [JsonPropertyName( "actual_commercial_operation_date")]
        public DateTime? ActualCommercialOperationDate { get; set; }

        [JsonPropertyName( "is_project_in_exploitation_phase")]
        public bool? IsProjectInExploitationPhase { get; set; }

        [JsonPropertyName( "is_brown_field_at_inception")]
        public bool? IsBrownFieldAtInception { get; set; }

        [JsonPropertyName( "is_partial_off_take")]
        public bool? IsPartialOffTake { get; set; }

        [JsonPropertyName( "maturity_off_take_to_debt_maturity_ratio")]
        public DateTime? MaturityOffTakeToDebtMaturityRatio { get; set; }

        [JsonPropertyName( "is_accessible_cashflow")]
        public bool? IsAccessibleCashflow { get; set; }

        [JsonPropertyName( "full_off_take_contract_maturity_date")]
        public DateTime? FullOffTakeContractMaturityDate { get; set; }

        [JsonPropertyName( "is_liquid_asset")]
        public bool? IsLiquidAsset { get; set; }

        [JsonPropertyName( "is_joint_contractor_in_case_epc_jv")]
        public bool? IsJointContractorInCaseEPCJV { get; set; }

        [JsonPropertyName( "is_several_contractor_in_case_epc_jv")]
        public bool? IsSeveralContractorInCaseEPCJV { get; set; }

        [JsonPropertyName( "force_belongs_to_supporting_group_in_case_of_default")]
        public bool? ForceBelongsToSupportingGroupInCaseOfDefault { get; set; }

        [JsonPropertyName( "comment")]
        public string? Comment { get; set; }

        [JsonPropertyName( "sponsor_specify_comment")]
        public string? SponsorSpecifyComment { get; set; }

        [JsonPropertyName( "version")]
        public object? Version { get; set; }

        [JsonPropertyName( "status")]
        public string? Status { get; set; }

        [JsonPropertyName( "sti1_id")]
        public string? Sti1Id { get; set; }

        [JsonPropertyName( "product_line")]
        public string? ProductLine { get; set; }

        [JsonPropertyName( "credit_file_label")]
        public string? CreditFileLabel { get; set; }

        [JsonPropertyName( "fo_analyst_code")]
        public string? FoAnalystCode { get; set; }

        [JsonPropertyName( "project_contractor_data")]
        public ProjectContractorData? ProjectContractorData { get; set; }

        [JsonPropertyName( "project_sponsor_data")]
        public ProjectSponsorData? ProjectSponsorData { get; set; }

        [JsonPropertyName( "project_off_taker_data")]
        public ProjectOffTakerData? ProjectOffTakerData { get; set; }
    }
}
