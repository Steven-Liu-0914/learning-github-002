﻿using System;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class Root
    {
        [JsonPropertyName( "container")]
        public Container? Container { get; set; }
    }
}
