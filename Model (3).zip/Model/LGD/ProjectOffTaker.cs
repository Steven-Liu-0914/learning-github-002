﻿using System;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class ProjectOffTaker
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "with_ricos_id")]
        public bool? WithRicosId { get; set; }

        [JsonPropertyName( "ricos_id")]
        public string? RicosId { get; set; }

        [JsonPropertyName( "short_name")]
        public string? ShortName { get; set; }

        [JsonPropertyName( "are_cashflows_contracted")]
        public bool? AreCashflowsContracted { get; set; }

        [JsonPropertyName( "are_cashflows_over_loan_maturity")]
        public bool? AreCashflowsOverLoanMaturity { get; set; }

        [JsonPropertyName( "contract_cashflow_to_debt_ratio")]
        public double? ContractCashflowToDebtRatio { get; set; }

        [JsonPropertyName( "comment")]
        public string? Comment { get; set; }
    }
}
