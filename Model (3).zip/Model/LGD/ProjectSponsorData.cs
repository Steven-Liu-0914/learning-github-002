﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class ProjectSponsorData
    {
        [JsonPropertyName( "project_sponsor")]
        public List<object>? ProjectSponsor { get; set; }
    }
}
