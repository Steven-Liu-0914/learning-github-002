﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class LegalEntityDataList
    {
        public string? Id { get; set; }
        [JsonPropertyName( "is_new_or_to_override")]
        public string? IsNewOrToOverride { get; set; }
        [JsonPropertyName( "final_internal_rating")]
        public string? FinalInternalRating { get; set; }
        [JsonPropertyName( "macro_sector")]
        public string? MacroSector { get; set; }
        [JsonPropertyName( "external_rating_data")]
        public ExternalRatingData? ExternalRatingData { get; set; }
    }
}
