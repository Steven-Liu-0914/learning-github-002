﻿using System.Runtime.Serialization; // Required for DataMember attribute
using CACIB.CREW.Api.Features.Simulation.Model;
using CACIB.CREW.Api.Infrastructure;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class CalculationResultResponse : BaseResponse
    {
        [JsonPropertyName( "data")]
        public new AplResponseResult? Data { get; set; }
    }
}
