﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationEvaIndicatorResultItem
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "ccy_result")]
        public string? CcyResult { get; set; }

        [JsonPropertyName( "revenue")]
        public double? Revenue { get; set; }

        [JsonPropertyName( "capital_cost_ratio")]
        public double? CapitalCostRatio { get; set; }

        [JsonPropertyName( "eva")]
        public double? EVA { get; set; }
    }
}
