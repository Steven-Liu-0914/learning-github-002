﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseEclSimulationResultData
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "apl_response_ecl_indicateur_data")]
        public AplResponseEclIndicateurData? AplResponseEclIndicateurData { get; set; }
    }
}
