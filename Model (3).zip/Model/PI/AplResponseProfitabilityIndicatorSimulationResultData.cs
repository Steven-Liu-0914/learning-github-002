﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseProfitabilityIndicatorSimulationResultData
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "apl_response_profitability_indicator_result_item")]
        public AplResponseProfitabilityIndicatorResultItem? AplResponseProfitabilityIndicatorResultItem { get; set; }

        [JsonPropertyName( "apl_response_revenue_indicator_result_item")]
        public AplResponseRevenueIndicatorResultItem? AplResponseRevenueIndicatorResultItem { get; set; }

        [JsonPropertyName( "apl_response_liquidity_cost_indicator_result_item")]
        public AplResponseLiquidityCostIndicatorResultItem? AplResponseLiquidityCostIndicatorResultItem { get; set; }

        [JsonPropertyName( "apl_response_operational_risk_indicator_result_item")]
        public AplResponseOperationalRiskIndicatorResultItem? AplResponseOperationalRiskIndicatorResultItem { get; set; }

        [JsonPropertyName( "apl_response_regulatory_indicateur_result_item")]
        public AplResponseRegulatoryIndicateurResultItem? AplResponseRegulatoryIndicateurResultItem { get; set; }
    }
}
