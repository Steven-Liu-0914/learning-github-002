﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseRwairbaPortion
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "pd")]
        public double? PD { get; set; }

        [JsonPropertyName( "lgd")]
        public double? LGD { get; set; }

        [JsonPropertyName( "effective_maturity")]
        public double? EffectiveMaturity { get; set; }
    }
}
