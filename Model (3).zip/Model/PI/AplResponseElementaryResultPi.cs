﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseElementaryResultPi
    {
        [JsonPropertyName( "apl_response_pi_result_by_group_data_list")]
        public List<AplResponseResultByGroupData>? AplResponsePiResultByGroupDataList { get; set; }
    }
}
