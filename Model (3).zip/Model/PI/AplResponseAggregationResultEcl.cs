﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationResultEcl
    {
        [JsonPropertyName( "f1")]
        public List<AplResponseAggregationEclSimulationResultItem>? F1 { get; set; }

        [JsonPropertyName( "f2")]
        public List<AplResponseAggregationEclSimulationResultItem>? F2 { get; set; }

        [JsonPropertyName( "counterparty")]
        public List<AplResponseAggregationEclSimulationResultItem>? Counterparty { get; set; }

        [JsonPropertyName( "portfolio")]
        public List<AplResponseAggregationEclSimulationResultItem>? Portfolio { get; set; }
    }
}
