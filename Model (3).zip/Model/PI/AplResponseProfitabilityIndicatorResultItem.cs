﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseProfitabilityIndicatorResultItem
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "ccy_result")]
        public string? CcyResult { get; set; }

        [JsonPropertyName( "liquidity_cost")]
        public double? LiquidityCost { get; set; }

        [JsonPropertyName( "expected_loss")]
        public double? ExpectedLoss { get; set; }

        [JsonPropertyName( "total_cost")]
        public double? TotalCost { get; set; }

        [JsonPropertyName( "rwa_credit_risk")]
        public double? RwaCreditRisk { get; set; }

        [JsonPropertyName( "rwa_operational_risk")]
        public double? RwaOperationalRisk { get; set; }

        [JsonPropertyName( "total_rwa")]
        public double? TotalRwa { get; set; }

        [JsonPropertyName( "profitability_indicateur")]
        public double? ProfitabilityIndicateur { get; set; }

        [JsonPropertyName( "monthly_profil")]
        public AplResponseMonthlyProfilData? MonthlyProfil { get; set; }
    }
}
