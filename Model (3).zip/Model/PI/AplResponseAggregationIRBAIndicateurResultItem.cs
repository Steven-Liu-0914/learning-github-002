﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationIrbaIndicateurResultItem
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "is_with_portion")]
        public bool? IsWithPortion { get; set; }

        [JsonPropertyName( "ccy_result")]
        public string? CcyResult { get; set; }

        [JsonPropertyName( "counterparty_id")]
        public string? CounterpartyId { get; set; }

        [JsonPropertyName( "ead_before_ccf_application")]
        public double? EadBeforeCCFApplication { get; set; }

        [JsonPropertyName( "ead")]
        public double? EAD { get; set; }

        [JsonPropertyName( "average_effective_maturity")]
        public double? AverageEffectiveMaturity { get; set; }

        [JsonPropertyName( "rwa")]
        public double? RWA { get; set; }

        [JsonPropertyName( "nb_rwa_irba_portion")]
        public int? NbRWAIRBAPortion { get; set; }

        [JsonPropertyName( "map_rwa_irba_portion")]
        public AplResponseMapRwairbaPortion? MapRWAIRBAPortion { get; set; }
    }
}
