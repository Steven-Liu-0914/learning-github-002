﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseRevenueIndicatorResultItem
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "technical_id")]
        public string? TechnicalId { get; set; }

        [JsonPropertyName( "weighted_average_life")]
        public double? WeightedAverageLife { get; set; }

        [JsonPropertyName( "ccy_result")]
        public string? CcyResult { get; set; }

        [JsonPropertyName( "commitment")]
        public double? Commitment { get; set; }

        [JsonPropertyName( "draw_amount")]
        public double? DrawAmount { get; set; }

        [JsonPropertyName( "undrawn_amount")]
        public double? UndrawnAmount { get; set; }

        [JsonPropertyName( "commitment_fee")]
        public double? CommitmentFee { get; set; }

        [JsonPropertyName( "margin")]
        public double? Margin { get; set; }

        [JsonPropertyName( "revenues")]
        public double? Revenues { get; set; }

        [JsonPropertyName( "margin_and_commitment_fee_revenues")]
        public double? MarginAndCommitmentFeeRevenues { get; set; }

        [JsonPropertyName( "facility_fee_revenues")]
        public double? FacilityFeeRevenues { get; set; }

        [JsonPropertyName( "equivalent_facility_fee_in_basis_point")]
        public double? EquivalentFacilityFeeInBasisPoint { get; set; }

        [JsonPropertyName( "equivalent_margin_and_commitment_fee_in_basis_point")]
        public double? EquivalentMarginAndCommitmentFeeInBasisPoint { get; set; }

        [JsonPropertyName( "monthly_profil")]
        public AplResponseMonthlyProfilData? MonthlyProfil { get; set; }
    }
}
