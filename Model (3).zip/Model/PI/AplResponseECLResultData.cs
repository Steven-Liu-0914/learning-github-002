﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseEclResultData
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "transaction_id")]
        public string? TransactionId { get; set; }

        [JsonPropertyName( "tranch_id")]
        public string? TranchId { get; set; }

        [JsonPropertyName( "is_in_ecl_perimeter")]
        public bool? IsInEclPerimeter { get; set; }

        [JsonPropertyName( "is_in_ecl_perimeter_category")]
        public string? IsInEclPerimeterCategory { get; set; }

        [JsonPropertyName( "is_in_ecl_perimeter_comment")]
        public string? IsInEclPerimeterComment { get; set; }

        [JsonPropertyName( "calculation_type")]
        public string? CalculationType { get; set; }

        [JsonPropertyName( "is_calculation_by_dll_mqp_succeeded")]
        public bool? IsCalculationByDllMqpSucceeded { get; set; }

        [JsonPropertyName( "maturity")]
        public double? Maturity { get; set; }

        [JsonPropertyName( "elapsed_time")]
        public double? ElapsedTime { get; set; }

        [JsonPropertyName( "remaining_time")]
        public double? RemainingTime { get; set; }

        [JsonPropertyName( "exposure")]
        public double? Exposure { get; set; }

        [JsonPropertyName( "ccf")]
        public double? Ccf { get; set; }

        [JsonPropertyName( "ead")]
        public double? Ead { get; set; }

        [JsonPropertyName( "pd")]
        public double? Pd { get; set; }

        [JsonPropertyName( "lgd")]
        public double? Lgd { get; set; }

        [JsonPropertyName( "ecl")]
        public double? Ecl { get; set; }

        [JsonPropertyName( "bucket")]
        public string? Bucket { get; set; }

        [JsonPropertyName( "bucket_details")]
        public string? BucketDetails { get; set; }

        [JsonPropertyName( "bucket_low_credit_risk")]
        public string? BucketLowCreditRisk { get; set; }

        [JsonPropertyName( "bucket_sensitive_cpty")]
        public string? BucketSensitiveCpty { get; set; }

        [JsonPropertyName( "bucket_downgrade_rating")]
        public string? BucketDowngradeRating { get; set; }

        [JsonPropertyName( "bucket_sensitive_segment")]
        public string? BucketSensitiveSegment { get; set; }

        [JsonPropertyName( "fll_segment_scenario")]
        public double? FLL_Segment_Scenario { get; set; }

        [JsonPropertyName( "fll_region")]
        public string? FLL_Region { get; set; }

        [JsonPropertyName( "fll_segment")]
        public string? FLL_Segment { get; set; }

        [JsonPropertyName( "fll_scenario")]
        public double? FLL_Scenario { get; set; }

        [JsonPropertyName( "fll_product_penalty")]
        public double? FLL_Product_Penalty { get; set; }

        [JsonPropertyName( "fll_country_penalty")]
        public double? FLL_Country_Penalty { get; set; }

        [JsonPropertyName( "ccf_curve")]
        public string? CCFCurve { get; set; }

        [JsonPropertyName( "lgd_type")]
        public string? LGDType { get; set; }

        [JsonPropertyName( "lgd_curve")]
        public string? LGDCurve { get; set; }

        [JsonPropertyName( "pd_method")]
        public string? PDMethod { get; set; }

        [JsonPropertyName( "pd_curve")]
        public string? PDCurve { get; set; }
    }
}
