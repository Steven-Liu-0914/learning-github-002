﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseLiquidityCostIndicatorResultItem
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "ccy_result")]
        public string? CcyResult { get; set; }

        [JsonPropertyName( "legal_entity_id")]
        public string? LegalEntityId { get; set; }

        [JsonPropertyName( "category_id")]
        public string? CategoryId { get; set; }

        [JsonPropertyName( "drawn_liquidity_cost_rate")]
        public double? DrawnLiquidityCostRate { get; set; }

        [JsonPropertyName( "undrawn_liquidity_cost_rate")]
        public double? UndrawnLiquidityCostRate { get; set; }

        [JsonPropertyName( "equivalent_liquidity_cost_in_basis_point")]
        public double? EquivalentLiquidityCostInBasisPoint { get; set; }

        [JsonPropertyName( "monthly_profil")]
        public AplResponseMonthlyProfilData? MonthlyProfil { get; set; }
    }
}
