﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseMapEclPortionData
    {
        [JsonPropertyName( "apl_response_ecl_result_data")]
        public List<AplResponseEclResultData>? AplResponseEclResultData { get; set; }
    }
}
