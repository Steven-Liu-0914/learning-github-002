﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseElementaryResult
    {
        [JsonPropertyName( "ecl")]
        public AplResponseElementaryResultEcl? Ecl { get; set; }

        [JsonPropertyName( "pi")]
        public AplResponseElementaryResultPi? Pi { get; set; }
    }
}
