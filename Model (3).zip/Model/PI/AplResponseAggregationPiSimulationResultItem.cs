﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationPiSimulationResultItem
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "profitability_indicateur")]
        public AplResponseProfitabilityIndicatorResultItem? ProfitabilityIndicateur { get; set; }

        [JsonPropertyName( "revenue_indicator")]
        public AplResponseRevenueIndicatorResultItem? RevenueIndicator { get; set; }

        [JsonPropertyName( "liquidity_cost_indicator")]
        public AplResponseLiquidityCostIndicatorResultItem? LiquidityCostIndicator { get; set; }

        [JsonPropertyName( "operational_risk_indicator")]
        public AplResponseOperationalRiskIndicatorResultItem? OperationalRiskIndicator { get; set; }

        [JsonPropertyName( "eva_indicateur")]
        public AplResponseAggregationEvaIndicatorResultItem? EVAIndicateur { get; set; }

        [JsonPropertyName( "regulatory_indicateur")]
        public AplResponseRegulatoryIndicateurResultItem? RegulatoryIndicateur { get; set; }
    }
}
