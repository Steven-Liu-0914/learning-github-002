﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseResultByGroupData
    {
        [JsonPropertyName( "apl_response_multi_axis_data")]
        public AplResponseMultiAxisData? AplResponseMultiAxisData { get; set; }

        [JsonPropertyName( "apl_response_ecl_simulation_result_data_list")]
        public List<AplResponseEclSimulationResultData>? AplResponseEclSimulationResultDataList { get; set; }

        [JsonPropertyName( "apl_response_profitability_indicator_simulation_result_data_list")]
        public List<AplResponseProfitabilityIndicatorSimulationResultData>? AplResponseProfitabilityIndicatorSimulationResultDataList { get; set; }
    }
}
