﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseRegulatoryIndicateurResultItem
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "ccy_result")]
        public string? CcyResult { get; set; }

        [JsonPropertyName( "counterpart_id")]
        public string? CounterpartId { get; set; }

        [JsonPropertyName( "irba_indicateur")]
        public AplResponseAggregationIrbaIndicateurResultItem? IRBAIndicateur { get; set; }
    }
}
