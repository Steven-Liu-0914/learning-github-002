﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationResult
    {
        [JsonPropertyName( "ecl")]
        public AplResponseAggregationResultEcl? Ecl { get; set; }

        [JsonPropertyName( "pi")]
        public AplResponseAggregationResultPI? PI { get; set; }
    }
}
