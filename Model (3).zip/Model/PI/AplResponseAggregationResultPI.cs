﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationResultPI
    {
        [JsonPropertyName( "f1")]
        public List<AplResponseAggregationPiSimulationResultItem>? F1 { get; set; }

        [JsonPropertyName( "f2")]
        public List<AplResponseAggregationPiSimulationResultItem>? F2 { get; set; }

        [JsonPropertyName( "counterparty")]
        public List<AplResponseAggregationPiSimulationResultItem>? Counterparty { get; set; }

        [JsonPropertyName( "portfolio")]
        public List<AplResponseAggregationPiSimulationResultItem>? Portfolio { get; set; }
    }
}
