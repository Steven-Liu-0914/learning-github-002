﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseEclIndicateurData
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "is_with_portion")]
        public bool? IsWithPortion { get; set; }

        [JsonPropertyName( "exposure")]
        public double? Exposure { get; set; }

        [JsonPropertyName( "ead")]
        public double? Ead { get; set; }

        [JsonPropertyName( "ecl")]
        public double? Ecl { get; set; }

        [JsonPropertyName( "ecl_bucket_1")]
        public double? EclBucket1 { get; set; }

        [JsonPropertyName( "ecl_bucket_2")]
        public double? EclBucket2 { get; set; }

        [JsonPropertyName( "apl_response_map_ecl_portion_data")]
        public AplResponseMapEclPortionData? AplResponseMapEclPortionData { get; set; }
    }
}
