﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseMonthlyProfilData
    {
        [JsonPropertyName( "date")]
        public List<DateTime?>? Date { get; set; }

        [JsonPropertyName( "vect_revenue")]
        public List<double?>? VectRevenue { get; set; }

        [JsonPropertyName( "vect_liquidity_cost")]
        public List<double?>? VectLiquidityCost { get; set; }

        [JsonPropertyName( "vect_rwa_credit_risk")]
        public List<double?>? VectRWACreditRisk { get; set; }

        [JsonPropertyName( "vect_rwa_operational_risk")]
        public List<double?>? VectRwaOperationlRisk { get; set; }

        [JsonPropertyName( "vect_expected_loss")]
        public List<double?>? VectExpectedLoss { get; set; }

        [JsonPropertyName( "vect_profitability_indicator")]
        public List<double?>? VectProfitabilityIndicator { get; set; }

        [JsonPropertyName( "vect_eva")]
        public List<double?>? VectEVA { get; set; }

        [JsonPropertyName( "vect_drawn")]
        public List<double?>? VectDrawn { get; set; }

        [JsonPropertyName( "vect_undrawn")]
        public List<double?>? VectUndrawn { get; set; }

        [JsonPropertyName( "vect_ratio")]
        public List<double?>? VectRatio { get; set; }

        [JsonPropertyName( "vect_margin_revenue")]
        public List<double?>? VectMarginRevenue { get; set; }

        [JsonPropertyName( "vect_utilization_fee_revenue")]
        public List<double?>? VectUtilizationFeeRevenue { get; set; }

        [JsonPropertyName( "vect_commitment_revenue")]
        public List<double?>? VectCommitmentRevenue { get; set; }

        [JsonPropertyName( "vect_facility_fee_revenue")]
        public List<double?>? VectFacilityFeeRevenue { get; set; }

        [JsonPropertyName( "vect_floor_benefit_revenue")]
        public List<double?>? VectFloorBenefitRevenue { get; set; }

        [JsonPropertyName( "vect_drawn_liquidity_cost")]
        public List<double?>? VectDrawnLiquidityCost { get; set; }

        [JsonPropertyName( "vect_undrawn_liquidity_cost")]
        public List<double?>? VectUndrawnLiquidityCost { get; set; }

        [JsonPropertyName( "vect_operational_risk_rwa")]
        public List<double?>? VectOperationalRiskRwa { get; set; }
    }
}
