﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseSimulationError
    {
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "technical_id")]
        public string? TechnicalId { get; set; }

        [JsonPropertyName( "level")]
        public string? Level { get; set; }

        [JsonPropertyName( "level_id")]
        public string? LevelId { get; set; }

        [JsonPropertyName( "error")]
        public string? Error { get; set; }
    }
}
