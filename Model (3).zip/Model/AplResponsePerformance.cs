﻿using System.Runtime.Serialization; // Required for DataMember attribute

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponsePerformance
    {
        [JsonPropertyName( "elapsed_time")]
        public double? ElapsedTime { get; set; }

        [JsonPropertyName( "unit")]
        public string? Unit { get; set; }
    }
}
