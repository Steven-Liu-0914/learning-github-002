﻿using System.Text.Json.Serialization;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseContainer
    {
        //Shared Response
        [JsonPropertyName( "leaf_type")]
        public string? LeafType { get; set; }

        [JsonPropertyName( "id")]
        public string? Id { get; set; }

        [JsonPropertyName( "client_id")]
        public string? ClientId { get; set; }

        [JsonPropertyName( "context_id")]
        public string? ContextId { get; set; }

        [JsonPropertyName( "cut_off_id")]
        public string? CutOffId { get; set; }

        [JsonPropertyName( "client_simulation_id")]
        public string? ClientSimulationId { get; set; }

        //PI
        [JsonPropertyName( "aggregation_result")]
        public AplResponseAggregationResult? AggregationResult { get; set; }

        [JsonPropertyName( "elementary_result")]
        public AplResponseElementaryResult? ElementaryResult { get; set; }

        //LGD
        [JsonPropertyName( "simulation_time")]
        public DateTime? SimulationTime { get; set; }

        [JsonPropertyName( "user_ut")]
        public string? UserUT { get; set; }

        [JsonPropertyName( "is_official_calculation_with_db_insertion")]
        public bool? IsOfficialCalculationWithDbInsertion { get; set; }

        [JsonPropertyName( "simulation_requested_result")]
        public SimulationRequestedResult? SimulationRequestedResult { get; set; }

        [JsonPropertyName( "specialized_lending_project")]
        public SpecializedLendingProject? SpecializedLendingProject { get; set; }

        [JsonPropertyName( "legal_entity_data")]
        public LegalEntityData? LegalEntityData { get; set; }
    }
}
