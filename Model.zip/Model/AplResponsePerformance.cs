﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponsePerformance
    {
        public double? ElapsedTime { get; set; }

        public string? Unit { get; set; }
      
    }
}
