﻿using System.Globalization;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseResult
    {
        public AplResponseContainer? Container { get; set; }

        public AplResponseSimulationError? SimulationError { get; set; }

        public AplResponsePerformance? Performance { get; set; }
        
    }
}
