﻿namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseContainer
    {
        //Shared Response
        public string? LeafType { get; set; }

        public string? Id { get; set; }

        public string? ClientId { get; set; }

        public string? ContextId { get; set; }

        public string? CutOffId { get; set; }

        public string? ClientSimulationId { get; set; }


        //PI
        public AplResponseAggregationResult? AggregationResult { get; set; }

        public AplResponseElementaryResult? ElementaryResult { get; set; }


        //LGD
        public DateTime? SimulationTime { get; set; }
        public string? UserUT { get; set; }
        public bool? IsOfficialCalculationWithDbInsertion { get; set; }
        public SimulationRequestedResult? SimulationRequestedResult { get; set; }
        public SpecializedLendingProject? SpecializedLendingProject { get; set; }
        public LegalEntityData? LegalEntityData { get; set; }

    }
}
