﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class SimulationRequestedResult
    {
        public List<string>? OutputIndicators { get; set; }
    }
}
