﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class LegalEntityRating
    {
        public string? RatingAgency { get; set; }
        public string? Rating { get; set; }
        public DateTime? RatingDate { get; set; }
    }
}
