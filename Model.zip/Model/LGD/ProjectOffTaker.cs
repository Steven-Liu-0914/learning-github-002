﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class ProjectOffTaker
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public bool? WithRicosId { get; set; }
        public string? RicosId { get; set; }
        public string? ShortName { get; set; }
        public bool? AreCashflowsContracted { get; set; }
        public bool? AreCashflowsOverLoanMaturity { get; set; }
        public double? ContractCashflowToDebtRatio { get; set; }
        public string? Comment { get; set; }
    }

}
