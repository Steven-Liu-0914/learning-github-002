﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class SpecializedLendingProject
    {
        public string? LeafType { get; set; }
        public string? ProjectId { get; set; }
        public string? SpvId { get; set; }
        public string? SpvRiskCountry { get; set; }
        public string? Sector { get; set; }
        public string? HeadOfCommercialOrigin { get; set; }
        public object? CommercialOriginationEntity { get; set; }
        public bool? IsAcquisition { get; set; }
        public DateTime? TargetCommercialOperationDate { get; set; }
        public DateTime? ActualCommercialOperationDate { get; set; }
        public bool? IsProjectInExploitationPhase { get; set; }
        public bool? IsBrownFieldAtInception { get; set; }
        public bool? IsPartialOffTake { get; set; }
        public DateTime? MaturityOffTakeToDebtMaturityRatio { get; set; }
        public bool? IsAccessibleCashflow { get; set; }
        public DateTime? FullOffTakeContractMaturityDate { get; set; }
        public bool? IsLiquidAsset { get; set; }
        public bool? IsJointContractorInCaseEPCJV { get; set; }
        public bool? IsSeveralContractorInCaseEPCJV { get; set; }
        public bool? ForceBelongsToSupportingGroupInCaseOfDefault { get; set; }
        public string? Comment { get; set; }
        public string? SponsorSpecifyComment { get; set; }
        public object? Version { get; set; }
        public string? Status { get; set; }
        public string? Sti1Id { get; set; }
        public string? ProductLine { get; set; }
        public string? CreditFileLabel { get; set; }
        public string? FoAnalystCode { get; set; }
        public ProjectContractorData? ProjectContractorData { get; set; }
        public ProjectSponsorData? ProjectSponsorData { get; set; }
        public ProjectOffTakerData? ProjectOffTakerData { get; set; }
    }
}
