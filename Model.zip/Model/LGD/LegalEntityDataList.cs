﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class LegalEntityDataList
    {
        public string? Id { get; set; }
        [DataMember(Name = "is_new_or_to_override")]
        public string? IsNewOrToOverride { get; set; }
        [DataMember(Name = "final_internal_rating")]
        public string? FinalInternalRating { get; set; }
        [DataMember(Name = "macro_sector")]
        public string? MacroSector { get; set; }
        [DataMember(Name = "external_rating_data")]
        public ExternalRatingData? ExternalRatingData { get; set; }
    }
}
