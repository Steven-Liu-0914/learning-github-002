﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseSimulationError
    {
        public string? LeafType { get; set; }

        public string? Id { get; set; }

        public string? TechnicalId { get; set; }

        public string? Level { get; set; }

        public string? LevelId { get; set; }

        public string? Error { get; set; }   
    }
}
