﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseMonthlyProfilData
    {
        public List<DateTime?>? Date { get; set; }
        
        public List<double?>? VectRevenue { get; set; }
        public List<double?>? VectLiquidityCost { get; set; }
        public List<double?>? VectRWACreditRisk { get; set; }
        public List<double?>? VectRwaOperationlRisk { get; set; }
        public List<double?>? VectExpectedLoss { get; set; }
        public List<double?>? VectProfitabilityIndicator { get; set; }
        public List<double?>? VectEVA { get; set; }        
        public List<double?>? VectDrawn { get; set; }
        public List<double?>? VectUndrawn { get; set; }
        
        public List<double?>? VectRatio { get; set; }
        public List<double?>? VectMarginRevenue { get; set; }
        
        public List<double?>? VectUtilizationFeeRevenue { get; set; }
        public List<double?>? VectCommitmentRevenue { get; set; }
        public List<double?>? VectFacilityFeeRevenue { get; set; }
        
        public List<double?>? VectFloorBenefitRevenue { get; set; }
        public List<double?>? VectDrawnLiquidityCost { get; set; }
        public List<double?>? VectUndrawnLiquidityCost { get; set; }
        
        public List<double?>? VectOperationalRiskRwa { get; set; }

       
        
    }
}
