﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationEclSimulationResultItem
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public AplResponseAggregationEclIndicatorResultItem? EclIndicateur { get; set; }

    }
}
