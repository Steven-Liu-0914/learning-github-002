﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseMultiAxisData
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public List<string>? VectAxisId { get; set; }
        public List<string>? VectAxisValue { get; set; }
     
    }
}
