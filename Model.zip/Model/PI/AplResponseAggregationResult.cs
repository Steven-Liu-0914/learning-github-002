﻿using System.Globalization;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationResult
    {
        public AplResponseAggregationResultEcl? Ecl { get; set; }
        public AplResponseAggregationResultPI? PI { get; set; }
      
    }
}
