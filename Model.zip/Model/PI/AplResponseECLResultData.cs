﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseEclResultData
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public string? TransactionId { get; set; }
        public string? TranchId { get; set; }
        public bool? IsInEclPerimeter { get; set; }
        public string? IsInEclPerimeterCategory { get; set; }
        public string? IsInEclPerimeterComment { get; set; }
        public string? CalculationType { get; set; }
        public bool? IsCalculationByDllMqpSucceeded { get; set; }
        public double? Maturity { get; set; }
        public double? ElapsedTime { get; set; }
        public double? RemainingTime { get; set; }
        public double? Exposure { get; set; }
        public double? Ccf { get; set; }
        public double? Ead { get; set; }
        public double? Pd { get; set; }
        public double? lgd { get; set; }
        public double? Ecl { get; set; }
        public string? Bucket { get; set; }
        public string? BucketDetails { get; set; }
        public string? BucketLowCreditRisk { get; set; }
        public string? BucketSensitiveCpty { get; set; }
        public string? BucketDowngradeRating { get; set; }
        public string? BucketSensitiveSegment { get; set; }
        public double? FLL_Segment_Scenario { get; set; }
        public string? FLL_Region { get; set; }
        public string? FLL_Segment { get; set; }
        public double? FLL_Scenario { get; set; }
        public double? FLL_Product_Penalty { get; set; }
        public double? FLL_Country_Penalty { get; set; }
        public string? CCFCurve { get; set; }
        public string? LGDType { get; set; }
        public string? LGDCurve { get; set; }
        public string? PDMethod { get; set; }
        public string? PDCurve { get; set; }
        
    }
}
