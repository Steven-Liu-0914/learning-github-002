﻿using System.Globalization;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationResultEcl
    {
        public List<AplResponseAggregationEclSimulationResultItem>? F1 { get; set; }

        public List<AplResponseAggregationEclSimulationResultItem>? F2 { get; set; }

        public List<AplResponseAggregationEclSimulationResultItem>? Counterparty { get; set; }

        public List<AplResponseAggregationEclSimulationResultItem>? Portfolio { get; set; }
    
    }
}
