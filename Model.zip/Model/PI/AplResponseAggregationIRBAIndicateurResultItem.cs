﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationIrbaIndicateurResultItem
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }

        public bool? IsWithPortion { get; set; }

        public string? CcyResult { get; set; }

        public string? CounterpartyId { get; set; }
        public double? EadBeforeCCFApplication { get; set; }
        public double? EAD { get; set; }

        public double? AverageEffectiveMaturity { get; set; }

        public double? RWA { get; set; }


        public int? NbRWAIRBAPortion { get; set; }

        public AplResponseMapRwairbaPortion? MapRWAIRBAPortion { get; set; }
       
    }
}
