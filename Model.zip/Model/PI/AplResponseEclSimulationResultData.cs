﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseEclSimulationResultData
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public AplResponseEclIndicateurData? AplResponseEclIndicateurData { get; set; }        
       
    }
}
