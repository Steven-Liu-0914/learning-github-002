﻿using System.Globalization;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseElementaryResult
    {
        public AplResponseElementaryResultEcl? Ecl { get; set; }
        public AplResponseElementaryResultPi? Pi { get; set; }
       
    }
}
