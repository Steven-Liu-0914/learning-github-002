﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseRevenueIndicatorResultItem
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public string? TechnicalId { get; set; }
        public double? WeightedAverageLife { get; set; }

        public string? CcyResult { get; set; }
        
        
        public double? Commitment { get; set; }
        public double? DrawAmount { get; set; }
        public double? UndrawnAmount { get; set; }
        
        public double? CommitmentFee { get; set; }
        
        public double? Margin { get; set; }
        public double? Revenues { get; set; }
        
        public double? MarginAndCommitmentFeeRevenues { get; set; }
        public double? FacilityFeeRevenues { get; set; }
        
        public double? EquivalentFacilityFeeInBasisPoint { get; set; }        
        public double? EquivalentMarginAndCommitmentFeeInBasisPoint { get; set; }
        public AplResponseMonthlyProfilData? MonthlyProfil { get; set; }
      
    }
}
