﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseProfitabilityIndicatorResultItem
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public string? CcyResult { get; set; }        
        public double? LiquidityCost { get; set; }
        public double? ExpectedLoss { get; set; }
        public double? TotalCost { get; set; }
        public double? RwaCreditRisk { get; set; }
        public double? RwaOperationalRisk { get; set; }
        public double? TotalRwa { get; set; }
        public double? ProfitabilityIndicateur { get; set; }
        public AplResponseMonthlyProfilData? MonthlyProfil { get; set; }
      
    }
}
