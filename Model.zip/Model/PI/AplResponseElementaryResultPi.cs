﻿using System.Globalization;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseElementaryResultPi
    {
        public List<AplResponseResultByGroupData>? AplResponsePiResultByGroupDataList { get; set; }
       
    }
}
