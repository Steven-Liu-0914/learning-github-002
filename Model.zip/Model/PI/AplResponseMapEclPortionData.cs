﻿using System.Globalization;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseMapEclPortionData
    {
        public List<AplResponseEclResultData>? AplResponseEclResultData { get; set; }
    
    }
}
