﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationEvaIndicatorResultItem
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public string? CcyResult { get; set; }
        public double? Revenue { get; set; }
        public double? CapitalCostRatio { get; set; }
        public double? EVA { get; set; }      
    }
}
