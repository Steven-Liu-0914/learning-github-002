﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseProfitabilityIndicatorSimulationResultData
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public AplResponseProfitabilityIndicatorResultItem? AplResponseProfitabilityIndicatorResultItem { get; set; }
        public AplResponseRevenueIndicatorResultItem? AplResponseRevenueIndicatorResultItem { get; set; }
        public AplResponseLiquidityCostIndicatorResultItem? AplResponseLiquidityCostIndicatorResultItem { get; set; }
        
        public AplResponseOperationalRiskIndicatorResultItem? AplResponseOperationalRiskIndicatorResultItem { get; set; }
        public AplResponseRegulatoryIndicateurResultItem? AplResponseRegulatoryIndicateurResultItem { get; set; }

       
    }
}
