﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationPiSimulationResultItem
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public AplResponseProfitabilityIndicatorResultItem? ProfitabilityIndicateur { get; set; }
        public AplResponseRevenueIndicatorResultItem? RevenueIndicator { get; set; }
        public AplResponseLiquidityCostIndicatorResultItem? LiquidityCostIndicator { get; set; }
        public AplResponseOperationalRiskIndicatorResultItem? OperationalRiskIndicator { get; set; }
        public AplResponseAggregationEvaIndicatorResultItem? EVAIndicateur { get; set; }
        public AplResponseRegulatoryIndicateurResultItem? RegulatoryIndicateur { get; set; }
       
    }
}
