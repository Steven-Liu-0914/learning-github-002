﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseRegulatoryIndicateurResultItem
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        
        public string? CcyResult { get; set; }
        
        public string? CounterpartId { get; set; }
        public AplResponseAggregationIrbaIndicateurResultItem? IRBAIndicateur { get; set; }
              
    }
}
