﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationEclIndicatorResultItem
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }

        public string? CcyResult { get; set; }

        public bool? IsWithPortion { get; set; }

        public double? Exposure { get; set; }

        public double? Ead { get; set; }

        public double? Ecl { get; set; }

    }
}
