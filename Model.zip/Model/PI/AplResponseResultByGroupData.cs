﻿using System.Globalization;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseResultByGroupData
    {
        public AplResponseMultiAxisData? AplResponseMultiAxisData { get; set; }
        public List<AplResponseEclSimulationResultData>? AplResponseEclSimulationResultDataList { get; set; }
        public List<AplResponseProfitabilityIndicatorSimulationResultData>? AplResponseProfitabilityIndicatorSimulationResultDataList { get; set; }
       
    }
}
