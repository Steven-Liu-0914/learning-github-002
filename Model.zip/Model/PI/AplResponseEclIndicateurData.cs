﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseEclIndicateurData
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public bool? IsWithPortion { get; set; }
        public double? Exposure { get; set; }
        public double? Ead { get; set; }
        public double? Ecl { get; set; }
        public double? EclBucket1 { get; set; }
        public double? EclBucket2 { get; set; }
        public AplResponseMapEclPortionData? AplResponseMapEclPortionData { get; set; }
      
    }
}
