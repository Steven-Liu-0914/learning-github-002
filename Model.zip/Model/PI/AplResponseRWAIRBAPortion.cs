﻿using System.Globalization;
using System.Reflection;


namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseRwairbaPortion
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }

        public double? PD { get; set; }
        public double? LGD { get; set; }
        public double? EffectiveMaturity { get; set; }

       
    }
}
