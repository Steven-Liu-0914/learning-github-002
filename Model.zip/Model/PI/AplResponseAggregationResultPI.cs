﻿using System.Globalization;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseAggregationResultPI
    {
        public List<AplResponseAggregationPiSimulationResultItem>? F1 { get; set; }

        public List<AplResponseAggregationPiSimulationResultItem>? F2 { get; set; }

        public List<AplResponseAggregationPiSimulationResultItem>? Counterparty { get; set; }

        public List<AplResponseAggregationPiSimulationResultItem>? Portfolio { get; set; }
       
    }
}
