﻿using System.Globalization;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseMapRwairbaPortion
    {
        public AplResponseRwairbaPortion? RWAIRBAPortion { get; set; }
      
    }
}
