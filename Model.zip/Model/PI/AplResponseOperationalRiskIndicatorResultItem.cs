﻿using System.Globalization;
using System.Reflection;

namespace CACIB.CREW.Api.Features.Calculation.Model
{
    public class AplResponseOperationalRiskIndicatorResultItem
    {
        public string? LeafType { get; set; }
        public string? Id { get; set; }
        public string? CcyResult { get; set; }
        
        public AplResponseMonthlyProfilData? MonthlyProfil { get; set; }
      
    }
}
